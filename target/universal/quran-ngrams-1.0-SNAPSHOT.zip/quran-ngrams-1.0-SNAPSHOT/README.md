# quran-ngrams

http://quran-ngrams.net

Quran Ngram Analytics